window.onload = function () {
  let footer = document.getElementsByClassName("footer");
};
